# StructOCR Python SDK

[![PyPI version](https://badge.fury.io/py/structocr.svg)](https://badge.fury.io/py/structocr)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**The official Python client for [StructOCR](https://structocr.com).**

StructOCR is a powerful API tailored for developers to extract structured data from identity documents with high accuracy. This SDK helps you integrate **Passport OCR**, **National ID OCR**, and **Driver License OCR** into your Python applications in minutes.

👉 **[Get your Free API Key here](https://structocr.com)**

## Features

- **Passport OCR API**: Instantly extract MRZ, name, DOB, and expiry date from passports of 200+ countries.
- **National ID OCR**: Support for ID cards with automatic field mapping.
- **Driver License OCR**: Extract vehicle class, license number, and personal details.
- **Secure & Fast**: Enterprise-grade encryption and sub-second response times.

## Installation

Install the package via pip:

```bash
pip install structocr

```

## Quick Start

### 1. Initialize the Client

```python
from structocr import StructOCR

# Initialize with your API Key
client = StructOCR(api_key="sk_live_xxxxxxxx")

```

### 2. Scan a Passport (Passport OCR)

```python
# Pass the path to the passport image file
result = client.scan_passport('./docs/passport_sample.jpg')

print(f"Name: {result['data']['name']}")
print(f"Passport Number: {result['data']['document_number']}")

```

### 3. Scan a National ID or Driver License

```python
# National ID OCR
id_data = client.scan_national_id('./docs/id_card.png')

# Driver License OCR
license_data = client.scan_driver_license('./docs/license.jpg')

```

## Documentation

For full API documentation, response examples, and error codes, please visit the [StructOCR Developer Docs](https://www.structocr.com/developers?ref=github).

## Requirements

* Python 3.6+
* `requests` library

## License

MIT License. See [LICENSE](https://www.google.com/search?q=LICENSE) for details.cd